### Author: Jacob Christensen <Jacobjc2@gmail.com>
### Course: Introduction to Embedded Systems Software and Development Environments
### Assignment: Week 1 Application Assignment

### Description:
In this programming assignment we created a simple application that performs statistical analytics on a dataset. 

